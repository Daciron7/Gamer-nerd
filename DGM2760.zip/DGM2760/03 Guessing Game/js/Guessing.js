// JavaScript Document
/*jslint browser:true */
"use strict";

var myguess = "03 Guessing Game";
document.getElementById("title").innerHTML = myguess;

var myloop = "Loops";
document.getElementById("subtitle").innerHTML = myloop;

//Beginning of game
var randomNumber = (Math.floor(Math.random()*15)+1);

var guesses = document.querySelector(".guesses");
var lastResult = document.querySelector(".lastResult");
var lowOrHi = document.querySelector(".lowOrHi");

var guessSubmit = document.querySelector('.guessSubmit');
var guessField = document.querySelector('.guessField');

var guessCount = "";


function checkGuess() {
	
	var userGuess = Number(guessField.value);
	if (guessCount === 0){
		guesses.textContent = "Number of tries: ";
		guessCount += 1;
		return guessCount;
	}
	guesses.textContent = "Number of tries: " + guessCount;

	if (userGuess === randomNumber) {
		lastResult.textContent = "Congratulations! you have gotten it right!";
		lastResult.style.image = myMedals(guessCount);
		lowOrHi.textContent = "";
		setGameOver();
	} else if (guessCount === 12) {
		lastResult.textContent = "Game Over! Please refresh the page to try again";
		lastResult.style.image = myMedals(guessCount);
		setGameOver();
	}
	if (userGuess != randomNumber){
		lastResult.textContent = "Sorry! Try again";
		} 
		
	if (userGuess < randomNumber){
	 	lowOrHi.textContent = "Last guess was too low!";
	 	} 
	 else if(userGuess > randomNumber){
	 	lowOrHi.textContent = "Last guess was too high!";
	 }
	 
	 if (userGuess < 1){
	 	lastResult.textContent = "Please guess a number between 1 to 15";
	 	guessCount = 0;
	 } else if (userGuess > 15){
	 	lastResult.textContent = "Please guess a number between 1 to 15";
	 	guessCount = 0;
	 }

	
    
	guessCount++;
	guessField.value = "";
	guessField.focus();

}

guessSubmit.addEventListener("onclick", checkGuess);

function myMedals(numGuesses) {
var pathToImage;
var numGuesses;
console.log(numGuesses);
switch (numGuesses) {
	case 1:
	case 2:
	case 3:
	pathToImage = "images/gold-medal.png";
	break;
	case 4:
	case 5:
	case 6:
	pathToImage= "images/silver-medal.png";
	break;
	case 7:
	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	pathToImage= "images/bronze-medal.png";
	break;
	default:
	pathToImage= "images/bronze-medal.png";
	break;
}
var awardImage = document.createElement("IMG");
awardImage.setAttribute("src", pathToImage);

console.log(awardImage);

document.getElementById('medals').appendChild(awardImage);

} // end of function


function setGameOver() {
	guessField.disabled = true;
	guessSubmit.disabled = true;
	
}
setGameOver();






function resetGame(){
	guessCount = 1;

	var resetParas = document.querySelectorAll('.resultParasp');
	for (var i = 0; i< resetParas.length ; i++) {
		resetParas[i].textContent = " ";
	}

	guessField.disabled = false;
	guessSubmit.disabled = false;
	guessField.value = " ";
	guessField.focus();

	lastResult.style.image = "blank";

	randomNumber = Math.floor(Math.random()*15)+1;
}
resetGame();