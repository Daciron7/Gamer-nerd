// JavaScript Document
/*jslint browser:true */
"use strict";

var myTitle = "06 Nonsense Story";
document.getElementById("title").innerHTML = myTitle;

var mySubTitle = "String Manipulation";
document.getElementById("subTitle").innerHTML = mySubTitle;



function story() {
	var myNouns = document.getElementById('nouns').value.toLowerCase().split(/\s+|\r/);
	var myAdjectives = document.getElementById('adjectives').value.toLowerCase().split(/\s+|\r/);
	var myVerbs = document.getElementById('verbs').value.toLowerCase().split(/\s+|\n/);





	var myStory = "Once upon a time, there were three little "+myNouns[0]+"s. One day their mother came to them and said my "+myAdjectives[0]+" little ones, it is time to go out and make your "+myNouns[1]+"s, but be careful because of the "+myAdjectives[1]+" bad "+myNouns[2]+" will try to "+myVerbs[0]+" you. After that the little pigs "+myVerbs[1]+" onto an "+myAdjectives[2]+" adventure. The first pig, not being the brightest "+myNouns[3]+" decided to "+myVerbs[2]+" his house out of straw.";

	document.getElementById('feedback').innerHTML = myStory;
	console.log(myNouns);
	console.log(myAdjectives);
	console.log(myVerbs);
}











