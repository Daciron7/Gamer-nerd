// JavaScript Document
/*jslint browser:true */
"use strict";

var myTitle = "04 Fortune Teller";
document.getElementById("title").innerHTML= myTitle;

var mySubTitle = "Switch Statements";
document.getElementById("subTitle").innerHTML= mySubTitle;


function generateRandom(top) {
	var x = Math.random();
	x = x * top;
	x = (Math.floor(x)) + 1;
	return x;

} //end of function

function getMonth(month) {
	var monthDate;
	switch(month){
		case 1:
		monthDate = "January";
		break;
		case 2:
		monthDate = "February";
		break;
		case 3:
		monthDate = "March";
		break;
		case 4:
		monthDate = "April";
		break;
		case 5:
		monthDate = "May";
		break;
		case 6:
		monthDate = "June";
		break;
		case 7:
		monthDate = "July";
		break;
		case 8:
		monthDate = "August";
		break;
		case 9:
		monthDate = "September";
		break;
		case 10:
		monthDate = "October";
		break;
		case 11:
		monthDate = "November";
		break;
		case 12:
		monthDate = "December";
		break;
		default:
		monthDate = "Ugh!!!!!!";
	}
	return monthDate;
}// end of function






function getDay(day){
	var date;
	switch (day){
		case 1:
		date = 1;
		break;
		case 2:
		date = 2;
		break;
		case 3:
		date = 3;
		break;
		case 4:
		date = 4;
		break;
		case 5:
		date = 5;
		break;
		case 6: 
		date = 6;
		break;
		case 7:
		date = 7;
		break;
		case 8:
		date = 8;
		break;
		case 9:
		date = 9;
		break;
		case 10:
		date = 10;
		break;
		case 11:
		date = 11;
		break;
		case 12:
		date = 12;
		break;
		case 13:
		date = 13;
		break;
		case 14:
		date = 14;
		break;
		case 15:
		date = 15;
		break;
		case 16:
		date = 16;
		break;
		case 17:
		date = 17;
		break;
		case 18:
		date = 18;
		break;
		case 19:
		date = 19;
		break;
		case 20:
		date = 20;
		break;
		case 21:
		date = 21;
		break;
		case 22:
		date = 22;
		break;
		case 23:
		date = 23;
		break;
		case 24: 
		date = 24;
		break;
		case 25:
		date = 25;
		break;
		case 26:
		date = 26;
		break;
		case 27:
		date = 27;
		break;
		case 28:
		date = 28;
		break;
		case 29:
		date = 29;
		break;
		case 30:
		date = 30;
		break;
		default:
		date = "number out of range";
	}
	return date;
} // end of function



function myFortune(fortune) {
	var myMsg;
	switch (fortune){
	case 1: 
	myMsg = "You will meet the girl of your dreams!";
	break;
	case 2:
	myMsg = "You will receive a small gift, just to keep you happy.";
	break;
	case 3:
	myMsg = "You will receive a pie in the face! We're sorry.";
	break;
	case 4:
	myMsg = "You will receive an honorary title or award!";
	break;
	case 5:
	myMsg = "You will arm wrestle a bear!";
	break;
	}
	return myMsg;
} // end of function





var month = generateRandom(12);
var monthDate = getMonth(month);

var day = generateRandom(30);
var date = getDay(day);

var message = generateRandom(5);
var myMsg = myFortune(message);

var feedBackMessage = "On " + monthDate +" the "+ date + ": " + myMsg;

document.getElementById('feedback').innerHTML = feedBackMessage;