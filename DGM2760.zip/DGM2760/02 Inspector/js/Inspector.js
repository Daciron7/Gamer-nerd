// JavaScript Document
/*jslint browser:true */
"use strict";

function myWindowResize() {
var color = window.innerWidth;
var high = window.innerHeight;
var box = " My Window is "+ color +" wide and " + high + " high<br>";
document.getElementById("message").innerHTML = box;

var top = window.screenTop;
var left = window.pageXOffset;
var browser = " My Window offset is " + left + " to the left and " + top + " from the top.";
document.getElementById("statement").innerHTML = browser;

document.getElementById("demo").innerHTML = "My page URL is: " + document.URL;



}
myWindowResize();


var myglass = "Inspector Clouseau";
document.getElementById("title").innerHTML = myglass;

var myplace = "Properties";
document.getElementById("subtitle").innerHTML = myplace;


function myDocumentInfo() {

var x = " My webpage is called " + document.title;
document.getElementById("myTitle").innerHTML = x;




var doc = document.lastModified;
document.getElementById("doc").innerHTML = doc;
}
myDocumentInfo();