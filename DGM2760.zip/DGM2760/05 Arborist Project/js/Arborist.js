// JavaScript Document
/*jslint browser:true */
"use strict";

var myTitle = "05 Arborist Project";
document.getElementById('title').innerHTML = myTitle;

var mySubTitle = "Array Manipulation";
document.getElementById('subtitle').innerHTML = mySubTitle;




var treesArray = ["Birch", "Oak", "Redwood"];



	function displayArrayItems () {
	var myString= "";
	var i;
	for (i = 0; i < treesArray.length; i++) {
		myString += treesArray[i] + "<br>";
	}
	document.getElementById('displayTrees').innerHTML = myString;

}



	
var unshift = function() {
	var myString = "";
		myString += treesArray.unshift('Juniper');
	document.getElementById('displayTrees').innerHTML= myString;
	displayArrayItems();
};


var push = function(){
	treesArray.push('Pine');
	displayArrayItems();
};

var shift = function(){
	treesArray.shift();
	displayArrayItems();
};

var splice = function() {
	treesArray.splice(1,1);
	displayArrayItems();
};

var pop = function() {
	treesArray.pop();
	displayArrayItems();
};

var sort = function() {
	treesArray.sort();
	displayArrayItems();
};

var toLowerCase = function(){
	for(var i = 0; i < treesArray.length; i++){
	treesArray[i] = treesArray[i].toLowerCase();
	}
	displayArrayItems();
};

var display2 = function() {
	if (treesArray.length<3) {
	document.getElementById('message').innerHTML= "There is not a third item in the Tree list.";
	} else {
	document.getElementById('message').innerHTML= treesArray[2];
	displayArrayItems();
	}
	if (treesArray.length<0) {
		document.getElementById('message').innerHTML= "Please add an item to the Tree list.";
	}	
};

var display3 = function() {
	if (treesArray.length<4) {
	document.getElementById('message').innerHTML= "There is not a fourth item in the Tree list.";
	} else {
	document.getElementById('message').innerHTML= treesArray[3];
	displayArrayItems();
	}
	if (treesArray.length<0) {
		document.getElementById('message').innerHTML= "Please add an item to the Tree list.";
	}	
};





var y = document.getElementById('addTreeStart');
y.onclick = unshift;

var x = document.getElementById('addTreeEnd');
x.onclick = push;

var d = document.getElementById('removeFirstTree');
d.onclick = shift;

var u = document.getElementById('removeSecondTree');
u.onclick = splice;

var k = document.getElementById('removeLastTree');
k.onclick = pop;

var s = document.getElementById('listSort');
s.onclick = sort;

var j = document.getElementById('changeCase');
j.onclick = toLowerCase;

var a = document.getElementById('thirdTree');
a.onclick = display2;

var b = document.getElementById('fourthTree');
b.onclick = display3;
