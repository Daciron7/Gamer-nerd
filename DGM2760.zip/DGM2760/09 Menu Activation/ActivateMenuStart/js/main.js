// JavaScript Document
/*jslint browser:true */
"use strict";

var test = location.href;



var resultsArray = test.split('/');




var numberOfParts = resultsArray.length;



var pieceIWant = resultsArray[numberOfParts-1];





var docTest = document.querySelectorAll("ul#mainmenu li a");



var i;
for (i=0; i<docTest.length; i++) {
	var myPage = docTest[i].getAttribute("href");


	if (resultsArray[resultsArray.length-1] === myPage) {
		
		docTest[i].parentNode.className="active";

		if (docTest[i].parentNode.parentNode.parentNode.className==="" && (resultsArray[resultsArray.length-1]=== "hammer.php" || resultsArray[resultsArray.length-1]==="drill.php"))
		docTest[i].parentNode.parentNode.parentNode.className="parent";
		
	} else {
		docTest[i].parentNode.className="";
	}
}
	
