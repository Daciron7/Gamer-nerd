// JavaScript Document
/*jslint browser:true */
"use strict";

var myTitle = "07 Pizza Emporium";
document.getElementById('title').innerHTML = myTitle;

var mySubTitle = "Literal Objects";
document.getElementById('subTitle').innerHTML = mySubTitle;


var pizza = {
	doughType : "Thin Crust",
	topping: "Sausage",
	size: "Small",
	

	pizzaStuff: function() {
		var pizzaText = "Your pizza is: "+pizza.size+" with a "+pizza.doughType+" and "+pizza.topping+" and with cheese on it.";
		console.log(pizzaText);
		document.getElementById('feedback').innerHTML = pizzaText;
	},

	groceryList: function() {
	if (pizza.doughType === "Thin Crust"){
		var pizzaText = "Your pizza must have 1 cup of flour and 1 lbs of "+pizza.topping+" in order to make it.";
		document.getElementById('feedback').innerHTML = pizzaText;
	} else if (pizza.doughType === "Thick Crust"){
			var pizzaText = "Your pizza must have 4 cups of flour and 1 lbs of "+pizza.topping+" in order to make it.";
			document.getElementById('feedback').innerHTML = pizzaText;
	} if (pizza.size === "Large"){
		 	var pizzaText = "Your pizza must have 2 cups of flour and 1 lbs of "+pizza.topping+" in order to make it.";
			document.getElementById('feedback').innerHTML = pizzaText;
		}


	}
};

pizza.pizzaStuff();
pizza.doughType = "Thin Crust";
pizza.topping = "Pepperoni";
pizza.size = "Small";
pizza.pizzaStuff();

pizza.groceryList();
pizza.topping = "Sausage";
pizza.groceryList();