/*jslint browser:true */
"use strict";

function validateForm() {
	var x;
	var y;
	var c;
	var i;
	var j;
	var k;
	var p;
	var v;
	var status = true;

	var requiredSections = ['fullName', 'phoneNumber', 'payMethod', 'ccNumber'];
	for (k = 0; k<requiredSections.length; k++) {
		document.getElementById(requiredSections[k]).className = "normal";
	}


	x= document.forms.myForm.fullName.value;
	if (x=== "" || x=== null) {
		status = false;
		document.getElementById("fullName").className = "error";
	}


	y=document.forms.myForm.phoneNumber.value;
	y= y.replace(/-/g, '');
	if (y.length < 10 || y.length>15 ) {
		status = false;
		document.getElementById('phoneNumber').className = "error";
	}

	c= document.forms.myForm.ccNumber.value;
	c= c.replace(/ /g, '');
	if(c.length != 15 ) {
		status = false;
		document.getElementById('ccNumber').className = "error";
	}


	p = document.getElementsByName('payMethod');
	var foundCheckedButton = false;
	for (j=0; j<p.length; j++) {
		if (p[j].checked) {
			foundCheckedButton = true;
			break;
		}
	}

	if (foundCheckedButton === false) {
		status = false;
		document.getElementById('payMethod').className = "error";
	}


	v= document.forms.myForm.vehicle.selectedIndex;
	if(v === 0) {
		status = false;
		document.getElementById('vehicle').className = "error";
	}

	


	if (status === false) {
		document.getElementById('formProblems').className = "showErrorMsg";
	}
	return status;
}

