// JavaScript Document
/*jslint browser:true */
"use strict";

var myTitle = "08 Grants Tomb";
document.getElementById('title').innerHTML = myTitle;

var mySubTitle = "Literal Objects";
document.getElementById('subTitle').innerHTML = mySubTitle;

var myQuestion = {

	option1:"George",
	option2:"Grant",
	option3:"Melissa",
	option4:"Gerald",
	correct: 2,


	checkAnswer: function(x) {
		if (x==myQuestion.correct) {
			var myMessage = "You are correct.";
			console.log(myMessage);
		 	document.getElementById('message').innerHTML = myMessage;
		} else {
			var myMessage = "Sorry, try again.";
			console.log(myMessage);
		 	document.getElementById('message').innerHTML = myMessage;
		}
	},

	checkQuestion: function() {
		var myQuestion = "Who is buried in Grants Tomb?";
		console.log(myQuestion);
		document.getElementById('question').innerHTML= myQuestion;
	}


};

myQuestion.checkQuestion();
myQuestion.option1= "George";
myQuestion.option2= "Grant";
myQuestion.option3= "Melissa";
myQuestion.option4= "Gerald";
myQuestion.correct = 2;
myQuestion.checkQuestion();



