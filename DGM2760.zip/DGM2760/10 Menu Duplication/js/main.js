/*jslint browser:true */
"use strict";



function smartNav() {
	var temp = document.querySelectorAll('ul#primaryNavigation li a');
	var i;
	var jacket = document.createElement("UL");
for (i=0; i<temp.length; i++) {
	var temp2 = temp[i].getAttribute("href");
	var temp3 = temp[i].text;

	var diaper = document.createElement("A");
	var baby = document.createElement("LI");
	

	diaper.setAttribute('href', temp2);
	diaper.innerHTML = temp3;

	baby.appendChild(diaper);
	jacket.appendChild(baby);

	document.getElementById('smallNavArea').appendChild(jacket);

	}
	
}

smartNav();